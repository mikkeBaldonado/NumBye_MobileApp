 var cfrom = "";
  var cto = "";

   /* function getVal(from)
    {
      document.getElementById("from").value = from;

    }

    function getVal2(to)
    {
      document.getElementById("to").value = to;
    }*/

    function checkFrom() {
      var fromBtn = document.getElementsByName("from");
      var len = fromBtn.length;

      for (var i = 0; i < len; i++) {
        if (fromBtn[i].checked){
          //alert("you have selected the " + fromBtn[i].value);
          cfrom = fromBtn[i].value;
        }
      }
    }

    function checkTo() {
      var toBtn = document.getElementsByName("to");
      var len = toBtn.length;

      for (var i = 0; i < len; i++) {
        if (toBtn[i].checked){
          //alert("you have selected the " + toBtn[i].value);
          cto = toBtn[i].value;
        }
      }
    }


    function convert()
    {
       size = document.getElementById("firstNumber").value;

      
      /*if(cfrom == 1 && cto == 1){
        document.getElementById("result2").value = size;
      }
      else if(cfrom == 1 && cto == 2) {
        document.getElementById("result2").value = size / 8;
      }
      else if(cfrom == 1 && cto == 3) {
        document.getElementById("result2").value = (size / 8) / 8;
      }
      else if(cfrom == 1 && cto == 4) {
        document.getElementById("result2").value = ((size / 8) / 8) / 8;
      }
      else if(cfrom == 1 && cto == 5) {
        document.getElementById("result2").value = (((size / 8) / 8) / 8) / 8;
      }
      else if(cfrom == 1 && cto == 6) {
        document.getElementById("result2").value = ((((size / 8) / 8) / 8) / 8) / 8;
      }
      else{
        document.getElementById("result2").value = size * 8;
      }*/


        if(cfrom < cto){
            if(cfrom == 1 && cto != 1){
                var bytesize = size/8 ;
                if (cfrom == 1 && cto == 2){
                    document.getElementById("result3").innerHTML = bytesize;
                }
                else{
                    for(var x = 1; x < cto-cfrom; x++ ){
                      bytesize/=1024;
                    }
                    document.getElementById("result3").innerHTML = bytesize;
                }
            }
            else{
                for(var x=0; x < cto-cfrom; x++ ){
                    size/=1024;
                }
                document.getElementById("result3").innerHTML = size;
            }
                
        }
        else if (cfrom > cto ){
            if( cfrom != 1 && cto == 1){
                var bytesize = size*8 ;
                if (cfrom == 2 && cto == 1){
                    document.getElementById("result3").innerHTML = bytesize;
                }
                else{
                    for(var x=1; x < cfrom-cto; x++ ){
                      bytesize*=1024;
                      document.getElementById("result3").innerHTML = bytesize;
                    }
                }
            }
            else{
                for(var x=0; x < cfrom-cto; x++ ){
                  size*=1024;
                }
                document.getElementById("result3").innerHTML = size;
            }
            
        }
        else{
            document.getElementById("result3").innerHTML = size; //equal
        }
      
    }